//
//  main.m
//  Recursion Exercises
//
//  Created by Kelsye Anderson on 10/30/17.
//  Copyright © 2017 Kelsye Anderson. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
